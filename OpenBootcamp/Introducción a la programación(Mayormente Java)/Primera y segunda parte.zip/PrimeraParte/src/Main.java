public class Main {
    public static void main(String[] args) {

        System.out.println(suma(3,4,5));
    }
    public static int suma(int a, int b, int c){
        int resultado=0;
        resultado=a+b+c;
        return resultado;
    }
}