n=100
while n!=0:
    print(n)
    n-=1

