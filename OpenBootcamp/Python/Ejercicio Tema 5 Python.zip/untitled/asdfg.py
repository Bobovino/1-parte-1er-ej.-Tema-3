#Los años bisiestos son los años divisibles entre 4.
# Los años cuyos dos últimos dígitos son 00 NO son años bisiestos, excepto aquellos divisibles por 400.

print ("Introduce el año para comprobar si es bisiesto o no: ")
año=int(input())

def bisiesto(año):
    if año%4==0 and año%100!=0 or año%400==0:
        return "es bisiesto"
    else:
        return "no es bisiesto"

print("El año",año, bisiesto(año))