var factorial=1;

for (let i = 1; i <= 10; i++) {
    factorial *= i ;
    console.log(factorial);
  }
console.log("The factorial of 10 is: "+factorial);