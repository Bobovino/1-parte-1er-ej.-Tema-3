var factorial=1;
let i=1;

while (i<= 10) {
    factorial *= i ;
    console.log(factorial);
    i++
  }
console.log("The factorial of 10 is: "+factorial);