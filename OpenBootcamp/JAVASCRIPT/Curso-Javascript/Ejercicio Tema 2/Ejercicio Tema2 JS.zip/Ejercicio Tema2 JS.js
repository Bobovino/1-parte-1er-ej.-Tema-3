
var nacimiento=new Date(1997,3,29);
const libroFavorito={titulo:"El nombre del viento", autor:"Patrick Rothfuss", fecha:"27 de marzo de 2007", url:"https://es.wikipedia.org/wiki/El_nombre_del_viento"};
var listaElementos = ["Rodrigo Martínez",25,true,nacimiento,libroFavorito];

console.log(listaElementos)




