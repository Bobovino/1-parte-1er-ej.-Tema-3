//- Crea un archivo controller.js que exporte 2 funciones: suma(a, b) y multiplica(a, b)

export function suma(a,b){
    return a+b
}

export function multiplica(a,b){
    return a*b
}